#!/usr/bin/env python3

import os

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    rover_line_follower_dir = get_package_share_directory('rover_line_follower')
    xacro_file = 'urdf/simple_rover_quiz.urdf.xacro'

    model_path = os.path.join(rover_line_follower_dir, 'models')
    set_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=model_path
    )

    world_file = os.path.join(rover_line_follower_dir, 'worlds', 'track.world')

    robot_description = {'robot_description': Command(['xacro ', os.path.join(rover_line_follower_dir, xacro_file)])}

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('gazebo_ros'), 'launch', 'gazebo.launch.py')
        ),
        launch_arguments={'world': world_file}.items()
    )

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[robot_description],
        output='screen'
    )

    spawn_entity_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'rover',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.0',
            '-R', '0.0',
            '-P', '0.0',
            '-Y', '3.14159', 
        ],
        output='screen'
    )

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        output='screen'
    )

    command_viewer_node = Node(
        package='rover_line_follower',
        executable='command_viewer',
        output='screen'
    )

    image_processor_node = Node(
        package='rover_line_follower',
        executable='image_processor',
        output='screen'
    )

    return LaunchDescription([
        set_model_path,
        gazebo_launch,
        robot_state_publisher_node,
        spawn_entity_node,
        rviz_node,
        command_viewer_node,
        image_processor_node
    ])
