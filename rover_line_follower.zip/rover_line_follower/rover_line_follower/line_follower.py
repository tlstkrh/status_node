import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np

class LineFollower(Node):
    def __init__(self):
        super().__init__('line_follower')
        self.bridge = CvBridge()
        self.image_subscriber = self.create_subscription(
            Image,
            '/rover/camera/image_raw',
            self.image_callback,
            10)
        self.cmd_vel_publisher = self.create_publisher(
            Twist,
            '/cmd_vel',
            10)
        self.get_logger().info('Line Follower Node has been started.')

        self.Kp = 0.005
        self.Kd = 0.001
        self.Ki = 0.0
        self.previous_error = 0.0
        self.integral = 0.0
        self.last_error = 0.0

        self.turning = False
        self.turn_start_time = None
        self.turn_duration = 3.14  # 회전 시간 (초)

        self.at_end = False
        self.end_start_time = None

    def image_callback(self, msg):
        if self.turning:
            current_time = self.get_clock().now().nanoseconds / 1e9
            elapsed_time = current_time - self.turn_start_time

            if elapsed_time < self.turn_duration:
                twist = Twist()
                twist.linear.x = 0.0
                if self.last_error < 0:
                    twist.angular.z = 0.5  # 회전 속도 아니면  rpy찾기
                    twist.linear.x = 0.1
                else:
                    twist.angular.z = -0.5
                    twist.linear.x = 0.1
                self.cmd_vel_publisher.publish(twist)
                self.get_logger().info(f"Turning... ({elapsed_time:.2f}s)")
            else:
                self.turning = False
                self.get_logger().info("Turn completed")
        elif self.at_end:
            # 라인의 끝에서 전진 중인 경우
            current_time = self.get_clock().now().nanoseconds / 1e9
            elapsed_time = current_time - self.end_start_time

            if elapsed_time < 0.6:  # 전진 시간 설정 (예: 2초)
                twist = Twist()
                twist.linear.x = 2.0 # 전진 속도
                twist.angular.z = 0.0  # 직진
                self.cmd_vel_publisher.publish(twist)
                self.get_logger().info(f"At the end, moving forward... ({elapsed_time:.2f}s)")
            else:
                # 전진 완료, 로봇 정지
                twist = Twist()
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.cmd_vel_publisher.publish(twist)
                self.get_logger().info("Reached the end, stopping.")
                # 필요한 경우 노드 종료 또는 다른 동작 수행
                # self.destroy_node()
                # rclpy.shutdown()
        else:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

            hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

            lower_black = np.array([0, 0, 0])
            upper_black = np.array([180, 255, 50])  
            mask = cv2.inRange(hsv, lower_black, upper_black)

            height, width = mask.shape
            roi = mask[int(height/2):height, :]

            M = cv2.moments(roi)
            if M['m00'] > 0:
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                center = width / 2
                error = cx - center
                self.integral += error
                derivative = error - self.previous_error

                twist = Twist()
                twist.linear.x = 0.7  # 평속

                twist.angular.z = -(self.Kp * error + self.Kd * derivative + self.Ki * self.integral)

                self.previous_error = error
                self.last_error = error

                self.cmd_vel_publisher.publish(twist)

                self.get_logger().info("Following the line")
            else:
                if abs(self.previous_error) < 10:  
                    self.at_end = True
                    self.end_start_time = self.get_clock().now().nanoseconds / 1e9
                    self.get_logger().info("Line ended, moving forward before stopping.")
                else:
                    self.turning = True
                    self.turn_start_time = self.get_clock().now().nanoseconds / 1e9
                    self.get_logger().info("Line not found, starting to turn")

def main(args=None):
    rclpy.init(args=args)
    node = LineFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
