import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import sys

class ImageSubscriber(Node):
    def __init__(self):
        super().__init__('image_subscriber')

        self.subscription = self.create_subscription(
            Image,
            '/rover/camera/image_raw',  
            self.image_callback,
            10
        )
        self.subscription 

        self.bridge = CvBridge()
        self.get_logger().info('Image Subscriber Node has been started.')

    def image_callback(self, msg):
        self.get_logger().info('Image callback triggered')
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f'Error converting image: {e}')
            return

        rgb_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB)
        
        pixels = rgb_image.reshape(-1, 3)

        pixels = pixels.view([('r', pixels.dtype), ('g', pixels.dtype), ('b', pixels.dtype)])

        unique, counts = np.unique(pixels, return_counts=True)

        max_count_index = np.argmax(counts)
        dominant_color = unique[max_count_index]
        count = counts[max_count_index]

        dominant_color = (dominant_color['r'], dominant_color['g'], dominant_color['b'])

        self.get_logger().info(f'Dominant Color (R, G, B): {dominant_color}, Count: {count}')

        self.get_logger().info('Displaying image with OpenCV')
        cv2.imshow('Camera Image', cv_image)  
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()

    try:
        rclpy.spin(image_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        if rclpy.ok():
            image_subscriber.destroy_node()
            rclpy.shutdown()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
